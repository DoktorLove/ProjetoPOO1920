
/**
 * Escreva a descrição da classe EncomendaInexistente aqui.
 * 
 * @author (seu nome) 
 * @version (número de versão ou data)
 */
public class EncomendaInexistenteException extends Exception
{
    public EncomendaInexistenteException()
    {
        super();
    }
    public EncomendaInexistenteException(String message)
    {
        super(message);
    }
}
