
/**
 * Escreva a descrição da classe UserInexistenteException aqui.
 * 
 * @author (seu nome) 
 * @version (número de versão ou data)
 */
public class UserInexistenteException extends Exception
{
    public UserInexistenteException()
    {
        super();
    }
    
    public UserInexistenteException(String message)
    {
        super(message);
    }
}
